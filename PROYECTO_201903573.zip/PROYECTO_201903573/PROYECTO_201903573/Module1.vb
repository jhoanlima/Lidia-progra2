﻿
Module Module1


    Sub vinculo()
        End


    End Sub
End Module
