﻿Imports System.Math
Module Module1
    Public funcion(9) As String
    Public cine(9) As String
    Public entradas(9) As Integer
    Public subtotal(9) As Double
    Public descuento1(9) As Double
    Public descuento2(9) As Double
    Public total(9) As Double

    Public tarifa1A As Integer = 30
    Public tarifa2A As Integer = 35
    Public tarifa3A As Integer = 40
    Public tarifa4A As Integer = 40

    Public tarifa1B As Integer = 24
    Public tarifa2B As Integer = 34
    Public tarifa3B As Integer = 44
    Public tarifa4B As Integer = 44

    Public tarifa1C As Integer = 35
    Public tarifa2C As Integer = 40
    Public tarifa3C As Integer = 50
    Public tarifa4C As Integer = 50




    Public fila As Byte = 0

    Sub verificar()
        If fila < 9 Then

            If Form1.CMBfuncion.Text <> "" Then
            funcion(fila) = Form1.CMBfuncion.Text
        Else
            MsgBox("ERROR, no selecciono funcion")
        End If
        If Form1.CMBcine.Text <> "" Then
            cine(fila) = Form1.CMBcine.Text
        Else
            MsgBox("ERROR, no selecciono el cine")
        End If
            If IsNumeric(Form1.TXTentrada.Text) And Val(Form1.TXTentrada.Text) > 0 Then
                entradas(fila) = Val(Form1.TXTentrada.Text)
            Else
                MsgBox("ERROR, no ingreso el numero de entradas")
            End If
            'para mostrar los datos
            Form1.DataGridView1.Rows.Add(Str(funcion(fila)), cine(fila), Str(entradas(fila)), subtotal(fila))

        Else
            MsgBox("Lo sentimos, los vectores estan llenos")
        End If
        fila = fila + 1
    End Sub

    Sub calcular(A As Boolean, entradas As Double, B As Boolean)
        Dim subtotall As Double

        Dim funcionn As Integer
        funcionn = Val(Form1.CMBfuncion.Text)

        If A Then
            Select Case funcionn
                Case Is = 1
                    subtotall = entradas * tarifa1A
                Case Is = 2
                    subtotall = entradas * tarifa2A
                Case Is = 3
                    subtotall = entradas * tarifa3A
                Case Is = 4
                    subtotall = entradas * tarifa4A
            End Select
        End If

        If B Then
            Select Case funcionn
                Case Is = 1
                    subtotall = entradas * tarifa1B
                Case Is = 2
                    subtotall = entradas * tarifa2B
                Case Is = 3
                    subtotall = entradas * tarifa3B
                Case Is = 4
                    subtotall = entradas * tarifa4B
            End Select
        Else
            Select Case funcionn
                Case Is = 1
                    subtotall = entradas * tarifa1C
                Case Is = 2
                    subtotall = entradas * tarifa2C
                Case Is = 3
                    subtotall = entradas * tarifa3C
                Case Is = 4
                    subtotall = entradas * tarifa4C
            End Select
        End If
        subtotal(fila) = subtotall
    End Sub

    Sub limpiar()
        Form1.TXTentrada.Clear()

        Form1.CMBfuncion.Text = ""
        Form1.CMBcine.Text = ""

        Form1.DataGridView1.Rows.Clear()

    End Sub

End Module
